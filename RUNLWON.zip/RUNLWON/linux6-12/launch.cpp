#include <iostream>
#include <cstdlib>
#include <filesystem>

namespace fs = std::filesystem;

int main() {
    std::cout << "============================================" << std::endl;
    std::cout << "        Linux CLI Starting...              " << std::endl;
    std::cout << "============================================" << std::endl;

    // 1. Disk imajı kontrolü
    std::string drivePath = "rootfs.qcow2";
    if (!fs::exists(drivePath)) {
        std::cerr << "[ERROR] 'rootfs.qcow2' file not found!" << std::endl;
        std::cerr << "Please run setup.exe first or place the image in this folder." << std::endl;
        system("pause");
        return 1;
    }

    // 2. QEMU çalıştırılabilir dosyasını otomatik bul
    std::string qemuPath = "";

    if (fs::exists("..\\tools\\qemu-system-x86_64.exe")) {
        qemuPath = "..\\tools\\qemu-system-x86_64.exe";
    } else if (fs::exists("C:\\Program Files\\qemu\\qemu-system-x86_64.exe")) {
        qemuPath = "\"C:\\Program Files\\qemu\\qemu-system-x86_64.exe\"";
    } else {
        int check = system("qemu-system-x86_64 --version >nul 2>&1");
        if (check == 0) {
            qemuPath = "qemu-system-x86_64";
        }
    }

    if (qemuPath.empty()) {
        std::cerr << "[ERROR] QEMU emulator not found in the system!" << std::endl;
        std::cerr << "Please install QEMU on your computer (C:\\Program Files\\qemu) or place it in the ..\\tools folder." << std::endl;
        system("pause");
        return 1;
    }

    // 3. .qcow2 imajını doğrudan çalıştıracak QEMU komutu
    std::string cmd = qemuPath + 
        " -m 1024M" +
        " -smp 2" +
        " -drive file=" + drivePath + ",format=qcow2,if=virtio" +
        " -net nic,model=virtio -net user" +
        " -nographic";

    std::cout << "[INFO] QEMU başlatılıyor..." << std::endl;
    int code = system(cmd.c_str());

    if (code != 0) {
        std::cerr << "\n[ERROR] QEMU unexpectedly closed (Error Code: " << code << ")" << std::endl;
        system("pause");
    }

    return code;
}