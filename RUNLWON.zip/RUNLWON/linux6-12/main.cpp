#include <iostream>
#include <filesystem>
#include "include/utils.hpp"
#include "include/downloader.hpp"
#include "include/extractor.hpp"

namespace fs = std::filesystem;

int main() {
    std::cout << "============================================" << std::endl;
    std::cout << "      Welcome to RUNLWON Setup!            " << std::endl;
    std::cout << "============================================" << std::endl;

    std::string baseDir = "C:\\linux6-12";
    std::string debianDir = baseDir + "\\Debian";
    std::string toolsDir = baseDir + "\\tools";

    Utils::createDirIfNotExist(baseDir);
    Utils::createDirIfNotExist(debianDir);
    Utils::createDirIfNotExist(toolsDir);

    std::string kernelUrl = "https://gemmei.ftp.acc.umu.se/cdimage/cloud/bookworm/latest/debian-12-generic-amd64.qcow2";
    std::string targetImage = debianDir + "\\rootfs.qcow2";

    if (!fs::exists(targetImage)) {
        std::cout << "[1/2] Debian 12 CLI İmajı indiriliyor..." << std::endl;
        if (!Downloader::downloadFile(kernelUrl, targetImage)) {
            std::cerr << "[ERROR] Debian 12 file could not be downloaded." << std::endl;
            return 1;
        }
    } else {
        std::cout << "[INFO] Debian 12 file already exists, skipping download." << std::endl;
    }

    try {
        if (fs::exists("linuxadd.exe")) {
            fs::copy_file("linuxadd.exe", baseDir + "\\linuxadd.exe", fs::copy_options::overwrite_existing);
        }
        if (fs::exists("launch.exe")) {
            fs::copy_file("launch.exe", debianDir + "\\launch.exe", fs::copy_options::overwrite_existing);
        }
    } catch (const std::exception& e) {
        std::cout << "[INFO] Files are copied successfully: " << e.what() << std::endl;
    }

    std::cout << "\n[SUCCESS] Setup completed!" << std::endl;
    std::cout << "Debian CLI location: C:\\linux6-12\\Debian" << std::endl;
    std::cout << "To add a distribution: C:\\linux6-12\\linuxadd.exe" << std::endl;

    return 0;
}