#include "../include/downloader.hpp"
#include <iostream>
#include <windows.h>
#include <urlmon.h>

namespace Downloader {
    bool downloadFile(const std::string& url, const std::string& outputPath) {
        std::cout << "[INFO] Downloading: " << url << std::endl;
        
        // Windows Native API kullanarak doğrudan ve güvenli indirme
        HRESULT hr = URLDownloadToFileA(NULL, url.c_str(), outputPath.c_str(), 0, NULL);
        if (SUCCEEDED(hr)) {
            return true;
        } else {
            std::cerr << "[ERROR] Download failed. Error Code: " << hr << std::endl;
            return false;
        }
    }
}