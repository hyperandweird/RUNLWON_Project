#include "../include/extractor.hpp"
#include "../include/utils.hpp"
#include <iostream>
#include <filesystem>

namespace fs = std::filesystem;

namespace Extractor {
    bool unpackRecursive(const std::string& archivePath, const std::string& targetDir) {
        if (!Utils::check7Zip()) {
            std::cerr << "[HATA] 7zip gereklidir." << std::endl;
            return false;
        }

        std::string zipExe = "7z";
        if (fs::exists("C:\\Program Files\\7-Zip\\7z.exe")) {
            zipExe = "\"C:\\Program Files\\7-Zip\\7z.exe\"";
        }

        std::string currentFile = archivePath;
        std::string tempExtractedDir = targetDir;

        while (true) {
            std::string ext = fs::path(currentFile).extension().string();
            if (ext != ".zip" && ext != ".gz" && ext != ".tar" && ext != ".xz" && ext != ".7z") {
                break;
            }

            std::cout << "[INFO] Arşiv açılıyor: " << currentFile << std::endl;
            std::string cmd = zipExe + " x \"" + currentFile + "\" -o\"" + tempExtractedDir + "\" -y >nul";
            
            if (Utils::runCommand(cmd) != 0) {
                std::cerr << "[HATA] Arşiv açma işlemi başarısız oldu." << std::endl;
                return false;
            }

            bool foundNested = false;
            for (const auto& entry : fs::directory_iterator(tempExtractedDir)) {
                std::string subExt = entry.path().extension().string();
                if (subExt == ".tar" || subExt == ".gz" || subExt == ".xz") {
                    currentFile = entry.path().string();
                    foundNested = true;
                    break;
                }
            }

            if (!foundNested) break;
        }

        return true;
    }
}