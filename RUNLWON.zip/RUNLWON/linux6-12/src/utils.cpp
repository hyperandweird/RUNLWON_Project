#include "../include/utils.hpp"
#include <iostream>
#include <cstdlib>
#include <filesystem>

namespace fs = std::filesystem;

namespace Utils {
    bool check7Zip() {
        int res = system("7z >nul 2>&1");
        if (res == 0) return true;
        
        return fs::exists("C:\\Program Files\\7-Zip\\7z.exe");
    }

    bool createDirIfNotExist(const std::string& path) {
        try {
            if (!fs::exists(path)) {
                return fs::create_directories(path);
            }
            return true;
        } catch (...) {
            return false;
        }
    }

    std::string getFileNameWithoutExt(const std::string& path) {
        fs::path p(path);
        return p.stem().string();
    }

    int runCommand(const std::string& cmd) {
        return system(cmd.c_str());
    }
}