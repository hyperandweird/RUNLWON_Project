#pragma once
#include <string>
#include <filesystem>

namespace fs = std::filesystem;

namespace Utils {
    bool check7Zip();
    bool createDirIfNotExist(const std::string& path);
    std::string getFileNameWithoutExt(const std::string& path);
    int runCommand(const std::string& cmd);
}