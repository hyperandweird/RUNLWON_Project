#pragma once
#include <string>

namespace Extractor {
    bool unpackRecursive(const std::string& archivePath, const std::string& targetDir);
}