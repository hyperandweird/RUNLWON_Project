#pragma once
#include <string>

namespace Downloader {
    bool downloadFile(const std::string& url, const std::string& outputPath);
}