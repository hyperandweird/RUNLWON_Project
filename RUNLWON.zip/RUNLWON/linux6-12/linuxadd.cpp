#include <iostream>
#include <string>
#include <filesystem>
#include "include/utils.hpp"
#include "include/extractor.hpp"

namespace fs = std::filesystem;

int main() {
    std::cout << "=== Linux Dağıtım Ekleme Sihirbazı ===" << std::endl;
    
    if (!Utils::check7Zip()) {
        std::cout << "7zip gereklidir." << std::endl;
        return 1;
    }

    std::string zipPath;
    std::cout << "Lütfen .zip veya arşiv dosyasının yolunu girin: ";
    std::getline(std::cin, zipPath);

    if (!fs::exists(zipPath)) {
        std::cerr << "[HATA] Belirtilen dosya bulunamadı!" << std::endl;
        return 1;
    }

    std::cout << "\nBu dağıtım, hangi işletim sisteminin temelini kullanmaktadır?" << std::endl;
    std::cout << "1: Debian/Ubuntu" << std::endl;
    std::cout << "2: Red Hat" << std::endl;
    std::cout << "3: Arch" << std::endl;
    std::cout << "4: Alpine" << std::endl;
    std::cout << "Seçiminiz (1-4): ";
    
    int choice;
    std::cin >> choice;
    std::cin.ignore();

    std::cout << "\nLütfen yeni Linux'a isim belirleyin...: ";
    std::string distroName;
    std::getline(std::cin, distroName);

    std::string targetDir = "C:\\linux6-12\\" + distroName;
    Utils::createDirIfNotExist(targetDir);

    std::cout << "\nDosyalar çıkarılıyor..." << std::endl;
    if (!Extractor::unpackRecursive(zipPath, targetDir)) {
        std::cerr << "[HATA] Çıkarma işlemi sırasında bir sorun oluştu." << std::endl;
        return 1;
    }

    try {
        if (fs::exists("C:\\linux6-12\\Debian\\launch.exe")) {
            fs::copy_file("C:\\linux6-12\\Debian\\launch.exe", targetDir + "\\launch.exe", fs::copy_options::overwrite_existing);
        }
    } catch (...) {
        std::cerr << "[UYARI] launch.exe kopyalanamadı." << std::endl;
    }

    std::cout << "\nHer şey tamam! Şimdi \"" << distroName << "\" klasörüne girip lütfen \"launch.exe\" dosyasını açın." << std::endl;

    return 0;
}